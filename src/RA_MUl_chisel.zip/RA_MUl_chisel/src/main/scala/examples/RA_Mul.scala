import chisel3._
import chisel3.util._
class HA extends Module {
  val io = IO(new Bundle {
    val s = Output(Bool())
    val cout = Output(Bool())
    val a = Input(Bool())
    val b = Input(Bool())
  })
  io.cout := io.a & io.b
  io.s := io.a ^ io.b
}

class FA extends Module {
  val io = IO(new Bundle {
    val s = Output(Bool())
    val cout = Output(Bool())
    val a = Input(Bool())
    val b = Input(Bool())
    val cin = Input(Bool())
  })

  io.s := io.a ^ io.b ^ io.cin
  io.cout := (io.a & io.b) | (io.a & io.cin) | (io.b & io.cin)

}

class BoothEncoder_radix4 (WIDTH : Int)
  extends Module {
  val io = IO(new Bundle {
    //val q = Vec(3, Output(Vec(3, Output(Bool()))))
    //val eB = Output(Vec(8, Vec(3, Bool())))
    val eB = Output(Vec(8, UInt(3.W)))
    val B = Input(UInt(WIDTH.W))
  })
  val B_ext = VecInit(io.B.toBools :+ 0.U.toBool).asUInt
  
  //io.q(1)(2) := 0.U
  for (i <- 0 until 8) {
     val eB_cur = Wire(Vec(3, Bool()))
     eB_cur(0) := B_ext(i+1) ^ B_ext(i)
     eB_cur(1) := (B_ext(i + 2) & (~B_ext(i + 1)) & (~B_ext(i))) | ((~B_ext(i + 2)) & B_ext(i + 1) & B_ext(i))
     eB_cur(2) := B_ext(i + 2)
     io.eB(i) := eB_cur.asUInt
   
  }

   
   

}

object BoothEncoderDriver extends App {
  chisel3.Driver.execute(args, () => new BoothEncoder_radix4(16))
}


